100% KBr
Data Acquired: Carlos H., Leah V., Dr. E. Grace
1/19/26

Laser Energy: 6
Laser Frequency: 2
Trigger: Edge 
Trigger Cable: Q-S
50 blasts
Lights: Off